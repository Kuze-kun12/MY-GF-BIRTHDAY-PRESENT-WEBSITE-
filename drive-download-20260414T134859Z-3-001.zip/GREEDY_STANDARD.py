import sys
import time
import math
import heapq

# --- DESIGN UTILITIES ---
def typewriter(text, speed=0.01):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_note(title, logic):
    print(f"\n{Colors.BOLD}{Colors.HEADER}--- STRATEGY NOTE: {title} ---{Colors.ENDC}")
    typewriter(f"{Colors.YELLOW}{logic}{Colors.ENDC}", 0.005)
    print("-" * 40)

# --- ALGORITHM LOGIC ---

def fractional_knapsack():
    print_note("Fractional Knapsack", 
               "Greedy Choice: Pick items with the highest Value/Weight ratio.\n"
               "Validation: Weights must be greater than zero.")
    
    try:
        line = input("Enter number of items: ")
        n = int(line)
        if n <= 0: raise ValueError("Number of items must be positive.")
        
        items = []
        for i in range(n):
            val = float(input(f"Value of item {i+1}: "))
            wt = float(input(f"Weight of item {i+1}: "))
            if wt <= 0: raise ValueError("Weight must be greater than zero to calculate ratio.")
            items.append({'id': i+1, 'v': val, 'w': wt, 'ratio': val/wt})
        
        capacity = float(input("Enter max capacity: "))
        if capacity < 0: raise ValueError("Capacity cannot be negative.")

        items.sort(key=lambda x: x['ratio'], reverse=True)
        total_value = 0
        
        for item in items:
            if capacity <= 0: break
            if item['w'] <= capacity:
                capacity -= item['w']
                total_value += item['v']
                print(f" [+] Full Item {item['id']} added. Remaining: {capacity:.2f}kg")
            else:
                fraction = capacity / item['w']
                total_value += item['v'] * fraction
                print(f" [%] Took {fraction*100:.1f}% of Item {item['id']}. Added ${item['v']*fraction:.2f}.")
                capacity = 0
        
        typewriter(f"{Colors.GREEN}Final Max Value: ${total_value:.2f}{Colors.ENDC}")
    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")

def activity_selection():
    print_note("Activity Selection", 
               "Greedy Choice: Pick the activity that ends the earliest.\n"
               "Validation: Start time must be less than end time.")
    
    try:
        n = int(input("Enter number of activities: "))
        if n <= 0: raise ValueError("Must have at least one activity.")
        
        activities = []
        for i in range(n):
            s = int(input(f"Start time {i+1}: "))
            e = int(input(f"End time {i+1}: "))
            if s >= e: raise ValueError("Start time must be strictly less than End time.")
            activities.append({'id': i+1, 's': s, 'e': e})
        
        activities.sort(key=lambda x: x['e'])
        selected = [activities[0]]
        print(f" [+] Selected Activity {activities[0]['id']} (Ends at {activities[0]['e']})")
        
        for i in range(1, n):
            if activities[i]['s'] >= selected[-1]['e']:
                selected.append(activities[i])
                print(f" [+] Activity {activities[i]['id']} fits.")
            else:
                print(f" [x] Activity {activities[i]['id']} overlaps. Skipping.")
        
        res = [str(a['id']) for a in selected]
        typewriter(f"{Colors.GREEN}Optimal Schedule: {', '.join(res)}{Colors.ENDC}")
    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")

def egyptian_fraction():
    print_note("Egyptian Fractions", "Greedy Choice: Subtract the largest unit fraction possible.")
    try:
        nr = int(input("Numerator: "))
        dr = int(input("Denominator: "))
        if dr == 0: raise ZeroDivisionError("Denominator cannot be zero.")
        if nr >= dr: raise ValueError("This algorithm is for proper fractions (Numerator < Denominator).")
        if nr <= 0 or dr <= 0: raise ValueError("Please use positive integers.")
        
        res = []
        while nr != 0:
            x = math.ceil(dr / nr)
            res.append(f"1/{x}")
            print(f" > Remaining {nr}/{dr} -> Subtracting 1/{x}")
            nr = x * nr - dr
            dr = dr * x
        typewriter(f"{Colors.GREEN}Result: {' + '.join(res)}{Colors.ENDC}")
    except (ValueError, ZeroDivisionError) as e:
        print(f"{Colors.FAIL}Error: {e}{Colors.ENDC}")

def traveling_salesman():
    print_note("Traveling Salesman (Greedy)", "Finds a path by always picking the closest unvisited city.")
    try:
        n = int(input("Number of cities: "))
        if n < 2: raise ValueError("Need at least 2 cities for a tour.")
        
        adj = []
        for i in range(n):
            row = list(map(int, input(f"Distances from City {i} to all {n} cities (space separated): ").split()))
            if len(row) != n: raise ValueError(f"Each row must contain exactly {n} values.")
            adj.append(row)
            
        visited = [False] * n
        curr, path, total = 0, [0], 0
        visited[0] = True
        
        for _ in range(n-1):
            nearest, min_d = -1, float('inf')
            for i in range(n):
                if not visited[i] and adj[curr][i] < min_d:
                    min_d, nearest = adj[curr][i], i
            if nearest == -1: raise ValueError("City is unreachable.")
            curr = nearest
            visited[curr] = True
            path.append(curr); total += min_d
            print(f" -> Next: City {curr} (Cost: {min_d})")
            
        total += adj[path[-1]][0]
        path.append(0)
        typewriter(f"{Colors.GREEN}Path: {'->'.join(map(str,path))} | Total Cost: {total}{Colors.ENDC}")
    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")

def job_sequencing():
    print_note("Job Sequencing", "Prioritize highest profit and schedule as late as possible.")
    try:
        n = int(input("Number of jobs: "))
        if n <= 0: raise ValueError("Need at least one job.")
        
        jobs = []
        for i in range(n):
            p = int(input(f"Profit of job {i+1}: "))
            d = int(input(f"Deadline of job {i+1}: "))
            if p < 0 or d <= 0: raise ValueError("Profit must be >= 0 and Deadline >= 1.")
            jobs.append({'id': i+1, 'p': p, 'd': d})
            
        jobs.sort(key=lambda x: x['p'], reverse=True)
        max_d = max(j['d'] for j in jobs)
        slots = [None] * max_d
        profit = 0
        
        for job in jobs:
            for j in range(min(max_d, job['d']) - 1, -1, -1):
                if slots[j] is None:
                    slots[j] = job['id']
                    profit += job['p']
                    print(f" [+] Job {job['id']} (Profit {job['p']}) -> Slot {j+1}")
                    break
        typewriter(f"{Colors.GREEN}Final Sequence: {[s for s in slots if s]} | Total Profit: {profit}{Colors.ENDC}")
    except ValueError as e:
        print(f"{Colors.FAIL}Error: {e}{Colors.ENDC}")

def huffman_coding():
    print_note("Huffman Coding", "Merge lowest frequency nodes to build an optimal binary tree.")
    
    try:
        text = input("Enter string to encode: ")
        if not text: raise ValueError("String cannot be empty.")
        
        freq = {c: text.count(c) for c in set(text)}
        if len(freq) < 2: 
            typewriter(f"{Colors.YELLOW}Warning: Only one unique character. Code is '0'.{Colors.ENDC}")
            print(f" '{text[0]}': 0")
            return

        heap = [[f, [c, ""]] for c, f in freq.items()]
        heapq.heapify(heap)
        
        while len(heap) > 1:
            lo, hi = heapq.heappop(heap), heapq.heappop(heap)
            for p in lo[1:]: p[1] = '0' + p[1]
            for p in hi[1:]: p[1] = '1' + p[1]
            heapq.heappush(heap, [lo[0]+hi[0]] + lo[1:] + hi[1:])
            
        codes = dict(heapq.heappop(heap)[1:])
        typewriter(f"{Colors.GREEN}Huffman Result:{Colors.ENDC}")
        for c in sorted(codes): print(f" '{c}': {codes[c]}")
    except Exception as e:
        print(f"{Colors.FAIL}Error: {e}{Colors.ENDC}")

# --- MAIN MENU ---

def main_menu():
    while True:
        print("\n" + "="*45)
        typewriter(f"{Colors.HEADER}{Colors.BOLD}   GREEDY ALGORITHM ARCHITECT v4.0   {Colors.ENDC}", 0.01)
        print("="*45)
        print(f"{Colors.YELLOW}[12] Fractional Knapsack   [15] Traveling Salesman")
        print("[13] Activity Selection     [16] Job Sequencing")
        print("[14] Egyptian Fraction      [17] Huffman Coding")
        print(f"[0]  Exit System{Colors.ENDC}")
        
        try:
            choice = input("\n> Choice: ").strip()
            if choice == '12': fractional_knapsack()
            elif choice == '13': activity_selection()
            elif choice == '14': egyptian_fraction()
            elif choice == '15': traveling_salesman()
            elif choice == '16': job_sequencing()
            elif choice == '17': huffman_coding()
            elif choice == '0': 
                typewriter(f"{Colors.FAIL}Exiting...{Colors.ENDC}")
                break
            else: print(f"{Colors.FAIL}Invalid option '{choice}'. Try again.{Colors.ENDC}")
        except KeyboardInterrupt:
            print("\nShutting down...")
            break

if __name__ == "__main__":
    main_menu()
