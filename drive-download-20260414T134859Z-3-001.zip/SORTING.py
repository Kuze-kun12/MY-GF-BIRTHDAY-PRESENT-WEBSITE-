import sys
import time
import math
import os

# --- 🎨 ZONE 1: COLOR THEORY & HIERARCHY ---
class Colors:
    HEADER = '\033[95m'  # Magenta: Professional Context
    LOGIC = '\033[93m'   # Yellow: Insight/Theory
    SUCCESS = '\033[92m' # Green: Optimal Solution
    FAIL = '\033[91m'    # Red: Error/Exclusion
    MENU = '\033[94m'    # Blue: Navigation
    CYAN = '\033[96m'    # Range/Processing
    BOLD = '\033[1m'
    ENDC = '\033[0m'

# --- ⌨️ ZONE 2: KINETIC TYPOGRAPHY ---
def typewriter(text, color=Colors.ENDC, speed=0.01):
    sys.stdout.write(color)
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print(Colors.ENDC)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# --- 📐 ZONE 3: VISUAL ENGINE ---
def render_bars(arr, title="SORTING", highlighting=None):
    if not arr: return
    clear_screen()
    
    max_val = max(arr)
    scale = 40 / max_val if max_val > 40 else 1

    print(f" {Colors.HEADER}[ {title} ]{Colors.ENDC}")
    print(f" {Colors.CYAN}Current State: {' '.join(map(str, arr))}{Colors.ENDC}\n")

    for i, val in enumerate(arr):
        bar_len = int(val * scale)
        bar = "█" * bar_len
        
        color = Colors.MENU
        icon = "  "
        
        if highlighting and i in highlighting:
            color = Colors.FAIL  
            icon = ">>"
            
        line = f" {icon} {color}{bar}{Colors.ENDC} ({val:02d})"
        print(line)
    print(f"\n{Colors.HEADER}{'='*50}{Colors.ENDC}")

def get_input_array():
    try:
        data = input(f"\n {Colors.BOLD}Enter numbers separated by spaces: {Colors.ENDC}")
        arr = [int(x) for x in data.split()]
        if not arr: raise ValueError("Array cannot be empty.")
        return arr
    except ValueError as e:
        print(f" {Colors.FAIL}Input Error: {e}{Colors.ENDC}")
        return None

# --- ⚙️ SORTING MODULES ---

def bubble_sort_visual():
    arr = get_input_array()
    if arr is None: return
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            render_bars(arr, "BUBBLE SORT", highlighting=[j, j+1])
            time.sleep(0.1)
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    render_bars(arr, "SORT COMPLETE")

def selection_sort_visual():
    arr = get_input_array()
    if arr is None: return
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            render_bars(arr, "SELECTION SORT", highlighting=[i, j])
            time.sleep(0.1)
            if arr[j] < arr[min_idx]: min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    render_bars(arr, "SORT COMPLETE")

def insertion_sort_visual():
    arr = get_input_array()
    if arr is None: return
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            render_bars(arr, "INSERTION SORT", highlighting=[j, j+1])
            time.sleep(0.1)
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    render_bars(arr, "SORT COMPLETE")

def merge_sort_visual():
    arr = get_input_array()
    if arr is None: return

    def merge(data, l, m, r):
        left_part, right_part = data[l:m+1], data[m+1:r+1]
        i = j = 0
        k = l
        while i < len(left_part) and j < len(right_part):
            render_bars(data, "MERGE SORT (MERGING)", highlighting=[k])
            time.sleep(0.1)
            if left_part[i] <= right_part[j]:
                data[k] = left_part[i]; i += 1
            else:
                data[k] = right_part[j]; j += 1
            k += 1
        while i < len(left_part): data[k] = left_part[i]; i += 1; k += 1
        while j < len(right_part): data[k] = right_part[j]; j += 1; k += 1

    def split_and_merge(data, l, r):
        if l < r:
            m = (l + r) // 2
            split_and_merge(data, l, m)
            split_and_merge(data, m + 1, r)
            merge(data, l, m, r)

    split_and_merge(arr, 0, len(arr)-1)
    render_bars(arr, "SORT COMPLETE")

def quick_sort_visual():
    arr = get_input_array()
    if arr is None: return

    def partition(data, low, high):
        pivot = data[high]
        i = low - 1
        for j in range(low, high):
            render_bars(data, "QUICK SORT", highlighting=[j, high])
            time.sleep(0.1)
            if data[j] < pivot:
                i += 1
                data[i], data[j] = data[j], data[i]
        data[i+1], data[high] = data[high], data[i+1]
        return i + 1

    def sort_logic(data, low, high):
        if low < high:
            pi = partition(data, low, high)
            sort_logic(data, low, pi - 1)
            sort_logic(data, pi + 1, high)

    sort_logic(arr, 0, len(arr)-1)
    render_bars(arr, "SORT COMPLETE")

# --- 💎 NEW: HEAP SORT MODULE ---
def heap_sort_visual():
    arr = get_input_array()
    if arr is None: return
    n = len(arr)

    def heapify(data, n, i):
        largest = i
        l, r = 2 * i + 1, 2 * i + 2
        
        render_bars(data, "HEAP SORT (HEAPIFY)", highlighting=[i, l if l < n else i, r if r < n else i])
        time.sleep(0.2)
        
        if l < n and data[i] < data[l]: largest = l
        if r < n and data[largest] < data[r]: largest = r
        if largest != i:
            data[i], data[largest] = data[largest], data[i]
            heapify(data, n, largest)

    # Build max heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    
    # Extract elements
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]
        render_bars(arr, "HEAP SORT (EXTRACTING MAX)", highlighting=[0, i])
        time.sleep(0.3)
        heapify(arr, i, 0)
        
    render_bars(arr, "SORT COMPLETE")
    typewriter(" [+] SUCCESS: Max-Heap extraction complete.", Colors.SUCCESS)

# --- 🏁 MAIN MENU ---

def main():
    while True:
        clear_screen()
        print(f"{Colors.BOLD}{Colors.HEADER}=============================================")
        print("      SORTING BAR ARCHITECT v6.0       ")
        print(f"============================================={Colors.ENDC}")
        print(f"{Colors.MENU} [1] Bubble Sort       [4] Merge Sort")
        print(f" [2] Selection Sort    [5] Quick Sort")
        print(f" [3] Insertion Sort    [6] Heap Sort")
        print(f" [0] Exit System{Colors.ENDC}")
        print(f"{Colors.HEADER}============================================={Colors.ENDC}")
        
        choice = input("\n [SYSTEM SELECT]: ")
        
        if choice == '1': bubble_sort_visual()
        elif choice == '2': selection_sort_visual()
        elif choice == '3': insertion_sort_visual()
        elif choice == '4': merge_sort_visual()
        elif choice == '5': quick_sort_visual()
        elif choice == '6': heap_sort_visual()
        elif choice == '0': 
            typewriter(" [x] DEACTIVATING SYSTEM...", Colors.FAIL)
            break
        else: continue
        input(f"\n{Colors.LOGIC}Press Enter to return to menu...{Colors.ENDC}")

if __name__ == "__main__":
    main()
