
import sys
import time
import heapq

# --- DESIGN UTILITIES ---
def typewriter(text, speed=0.01):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

class Colors:
    HEADER = '\033[95m'
    BLUE   = '\033[94m'
    GREEN  = '\033[92m'
    YELLOW = '\033[93m'
    FAIL   = '\033[91m'
    CYAN   = '\033[96m'
    ENDC   = '\033[0m'
    BOLD   = '\033[1m'

def print_note(title, logic):
    print(f"\n{Colors.BOLD}{Colors.HEADER}--- STRATEGY NOTE: {title} ---{Colors.ENDC}")
    typewriter(f"{Colors.YELLOW}{logic}{Colors.ENDC}", 0.005)
    print("-" * 40)

def get_graph_input():
    """
    Shared helper: reads V, E, and a weighted edge list.
    Returns (num_vertices, edges_list) where each edge is (u, v, w).
    Raises ValueError on any bad input.
    """
    V = int(input("Number of vertices (nodes): "))
    if V < 2:
        raise ValueError("Need at least 2 vertices.")

    E = int(input("Number of edges: "))
    if E < 1:
        raise ValueError("Need at least 1 edge.")

    print(f"Enter each edge as:  u  v  weight  (0-indexed, vertices 0 to {V-1})")
    edges = []
    for i in range(E):
        raw = input(f"  Edge {i+1}: ").split()
        if len(raw) != 3:
            raise ValueError(
                f"Edge {i+1}: expected exactly 3 values (u v weight), got {len(raw)}.")
        try:
            u, v, w = int(raw[0]), int(raw[1]), int(raw[2])
        except ValueError:
            raise ValueError(f"Edge {i+1}: all values must be integers.")
        if not (0 <= u < V):
            raise ValueError(f"Edge {i+1}: vertex {u} out of range (0 to {V-1}).")
        if not (0 <= v < V):
            raise ValueError(f"Edge {i+1}: vertex {v} out of range (0 to {V-1}).")
        if u == v:
            raise ValueError(f"Edge {i+1}: self-loops are not allowed.")
        if w < 0:
            raise ValueError(f"Edge {i+1}: negative weight {w} is not allowed.")
        edges.append((u, v, w))
    return V, edges


# ══════════════════════════════════════════════
#  UNION-FIND  (shared by Kruskal & Boruvka)
# ══════════════════════════════════════════════
def make_uf(n):
    return list(range(n)), [0] * n

def uf_find(parent, x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]   # path compression (halving)
        x = parent[x]
    return x

def uf_union(parent, rank, a, b):
    ra, rb = uf_find(parent, a), uf_find(parent, b)
    if ra == rb:
        return False          # already in same component -> would form a cycle
    if rank[ra] < rank[rb]:
        ra, rb = rb, ra
    parent[rb] = ra
    if rank[ra] == rank[rb]:
        rank[ra] += 1
    return True


# ══════════════════════════════════════════════
#  [18] KRUSKAL'S ALGORITHM  (MST)
# ══════════════════════════════════════════════
def kruskals():
    print_note(
        "Kruskal's MST",
        "Greedy Choice: Sort ALL edges by weight. Add the cheapest edge\n"
        "that does NOT form a cycle (detected via Union-Find / DSU).\n"
        "Repeat until exactly V-1 edges are in the MST.\n"
        "Works on: undirected, weighted, connected graphs."
    )
    try:
        V, edges = get_graph_input()
        parent, rank = make_uf(V)

        edges_sorted = sorted(edges, key=lambda e: e[2])
        mst, total = [], 0

        print(f"\n{Colors.CYAN}Processing edges sorted by weight:{Colors.ENDC}")
        for u, v, w in edges_sorted:
            if uf_union(parent, rank, u, v):
                mst.append((u, v, w))
                total += w
                print(f"  {Colors.GREEN}[+] Edge {u}--{v}  weight={w}"
                      f"  -> added to MST{Colors.ENDC}")
                if len(mst) == V - 1:
                    break
            else:
                print(f"  {Colors.FAIL}[x] Edge {u}--{v}  weight={w}"
                      f"  -> skipped (cycle){Colors.ENDC}")

        if len(mst) < V - 1:
            raise ValueError("Graph is disconnected — spanning tree impossible.")

        print()
        typewriter(f"{Colors.GREEN}MST Edges : {[(u,v,w) for u,v,w in mst]}{Colors.ENDC}")
        typewriter(f"{Colors.GREEN}Total Cost: {total}{Colors.ENDC}")

    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Unexpected Error: {e}{Colors.ENDC}")


# ══════════════════════════════════════════════
#  [19] BORUVKA'S ALGORITHM  (MST)
# ══════════════════════════════════════════════
def boruvkas():
    print_note(
        "Boruvka's MST",
        "Greedy Choice: In each phase, every component independently picks\n"
        "its cheapest outgoing edge; all selected edges are then merged.\n"
        "Phases repeat until only one component remains.\n"
        "Works on: undirected, weighted, connected graphs."
    )
    try:
        V, edges = get_graph_input()
        parent, rank = make_uf(V)

        mst_edges      = []
        total          = 0
        num_components = V
        phase          = 0

        while num_components > 1:
            phase    += 1
            cheapest  = {}   # component root -> (w, u, v)

            for u, v, w in edges:
                ru = uf_find(parent, u)
                rv = uf_find(parent, v)
                if ru == rv:
                    continue
                if ru not in cheapest or w < cheapest[ru][0]:
                    cheapest[ru] = (w, u, v)
                if rv not in cheapest or w < cheapest[rv][0]:
                    cheapest[rv] = (w, u, v)

            if not cheapest:
                raise ValueError("Graph is disconnected — spanning tree impossible.")

            print(f"\n{Colors.CYAN}Phase {phase} — cheapest edges per component:{Colors.ENDC}")
            seen = set()
            for root, (w, u, v) in cheapest.items():
                key = tuple(sorted((u, v)))
                if key in seen:
                    continue
                if uf_union(parent, rank, u, v):
                    mst_edges.append((u, v, w))
                    total          += w
                    num_components -= 1
                    seen.add(key)
                    print(f"  {Colors.GREEN}[+] Edge {u}--{v}  weight={w}"
                          f"  -> merged{Colors.ENDC}")

        print()
        typewriter(f"{Colors.GREEN}MST Edges : {[(u,v,w) for u,v,w in mst_edges]}{Colors.ENDC}")
        typewriter(f"{Colors.GREEN}Total Cost: {total}{Colors.ENDC}")

    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Unexpected Error: {e}{Colors.ENDC}")


# ══════════════════════════════════════════════
#  [20] PRIM'S ALGORITHM  (MST)
# ══════════════════════════════════════════════
def prims():
    print_note(
        "Prim's MST",
        "Greedy Choice: Start from vertex 0. Repeatedly add the cheapest\n"
        "edge that connects the visited set to any unvisited vertex.\n"
        "Uses a min-heap (priority queue) for O((V+E) log V) time.\n"
        "Works on: undirected, weighted, connected graphs."
    )
    try:
        V, edges = get_graph_input()

        adj = [[] for _ in range(V)]
        for u, v, w in edges:
            adj[u].append((w, v))
            adj[v].append((w, u))

        visited = [False] * V
        # heap format: (edge_weight, to_vertex, from_vertex)
        heap    = [(0, 0, -1)]
        mst     = []
        total   = 0

        print(f"\n{Colors.CYAN}Building MST from vertex 0:{Colors.ENDC}")

        while heap:
            w, u, src = heapq.heappop(heap)
            if visited[u]:
                continue
            visited[u] = True

            if src == -1:
                print(f"  {Colors.BLUE}[*] Start: vertex 0{Colors.ENDC}")
            else:
                mst.append((src, u, w))
                total += w
                print(f"  {Colors.GREEN}[+] Edge {src}--{u}  weight={w}"
                      f"  -> added{Colors.ENDC}")

            for ew, v in adj[u]:
                if not visited[v]:
                    heapq.heappush(heap, (ew, v, u))

        if len(mst) < V - 1:
            raise ValueError("Graph is disconnected — Prim's cannot complete the MST.")

        print()
        typewriter(f"{Colors.GREEN}MST Edges : {mst}{Colors.ENDC}")
        typewriter(f"{Colors.GREEN}Total Cost: {total}{Colors.ENDC}")

    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Unexpected Error: {e}{Colors.ENDC}")


# ══════════════════════════════════════════════
#  [21] DIAL'S ALGORITHM  (SSSP, integer weights)
# ══════════════════════════════════════════════
def dials():
    print_note(
        "Dial's Algorithm (Bucket-Queue SSSP)",
        "Greedy Choice: Like Dijkstra but uses a flat bucket array instead\n"
        "of a binary heap — one bucket slot per possible distance value.\n"
        "Best when edge weights are small, bounded non-negative integers.\n"
        "Time: O(V + E + V * W_max)."
    )
    try:
        V, edges = get_graph_input()

        W_max = int(input("Maximum edge weight W_max "
                          "(the largest weight in your graph): "))
        if W_max <= 0:
            raise ValueError("W_max must be a positive integer.")

        src = int(input(f"Source vertex (0 to {V-1}): "))
        if not (0 <= src < V):
            raise ValueError(f"Source vertex must be in range 0 to {V-1}.")

        adj = [[] for _ in range(V)]
        for u, v, w in edges:
            adj[u].append((v, w))
            adj[v].append((u, w))

        INF         = float('inf')
        dist        = [INF] * V
        dist[src]   = 0
        bucket_size = (V - 1) * W_max + 1
        buckets     = [[] for _ in range(bucket_size)]
        buckets[0].append(src)

        print(f"\n{Colors.CYAN}Dial's from vertex {src}  "
              f"| bucket_size={bucket_size}:{Colors.ENDC}")

        for idx in range(bucket_size):
            while buckets[idx]:
                u = buckets[idx].pop()
                # skip stale entries
                if dist[u] != idx:
                    continue

                print(f"  {Colors.BLUE}Settled vertex {u}  dist={idx}{Colors.ENDC}")

                for v, w in adj[u]:
                    new_d = dist[u] + w
                    if new_d < dist[v]:
                        dist[v] = new_d
                        if new_d < bucket_size:
                            buckets[new_d].append(v)
                            print(f"    {Colors.GREEN}-> Relaxed "
                                  f"{u}->{v}  dist[{v}]={new_d}{Colors.ENDC}")
                        else:
                            print(f"    {Colors.YELLOW}[!] dist[{v}]={new_d} "
                                  f"exceeds bucket range. "
                                  f"Raise W_max or use Dijkstra.{Colors.ENDC}")

        print()
        typewriter(f"{Colors.GREEN}Shortest distances from vertex {src}:{Colors.ENDC}")
        for i in range(V):
            label = str(dist[i]) if dist[i] != INF else "infinity (unreachable)"
            print(f"  Vertex {i}: {label}")

    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Unexpected Error: {e}{Colors.ENDC}")


# ══════════════════════════════════════════════
#  [22] DIJKSTRA'S ALGORITHM  (SSSP)
# ══════════════════════════════════════════════
def dijkstras():
    print_note(
        "Dijkstra's SSSP",
        "Greedy Choice: Always settle the unvisited vertex with the smallest\n"
        "known tentative distance (min-heap / lazy-deletion approach).\n"
        "Guarantees optimal shortest paths for non-negative edge weights.\n"
        "Reconstructs and prints the full shortest path to every vertex."
    )
    try:
        V, edges = get_graph_input()

        src = int(input(f"Source vertex (0 to {V-1}): "))
        if not (0 <= src < V):
            raise ValueError(f"Source vertex must be in range 0 to {V-1}.")

        adj = [[] for _ in range(V)]
        for u, v, w in edges:
            adj[u].append((w, v))
            adj[v].append((w, u))

        INF     = float('inf')
        dist    = [INF] * V
        prev    = [-1]  * V
        settled = [False] * V
        dist[src] = 0
        heap    = [(0, src)]

        print(f"\n{Colors.CYAN}Dijkstra's from vertex {src}:{Colors.ENDC}")

        while heap:
            d, u = heapq.heappop(heap)
            if settled[u]:
                continue
            settled[u] = True
            print(f"  {Colors.BLUE}Settled vertex {u}  dist={d}{Colors.ENDC}")

            for w, v in adj[u]:
                if settled[v]:
                    continue
                new_d = dist[u] + w
                if new_d < dist[v]:
                    dist[v] = new_d
                    prev[v] = u
                    heapq.heappush(heap, (new_d, v))
                    print(f"    {Colors.GREEN}-> Relaxed "
                          f"{u}->{v}  dist[{v}]={new_d}{Colors.ENDC}")

        def reconstruct(target):
            if dist[target] == INF:
                return None
            path, cur = [], target
            while cur != -1:
                path.append(cur)
                cur = prev[cur]
            return path[::-1]

        print()
        typewriter(f"{Colors.GREEN}Shortest distances from vertex {src}:{Colors.ENDC}")
        for i in range(V):
            if dist[i] == INF:
                print(f"  Vertex {i}: infinity (unreachable)")
            else:
                path     = reconstruct(i)
                path_str = " -> ".join(map(str, path))
                print(f"  Vertex {i}: dist={dist[i]}  path=[ {path_str} ]")

    except ValueError as e:
        print(f"{Colors.FAIL}Input Error: {e}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}Unexpected Error: {e}{Colors.ENDC}")


# ══════════════════════════════════════════════
#  MAIN MENU
# ══════════════════════════════════════════════
def main_menu():
    while True:
        print("\n" + "=" * 50)
        typewriter(
            f"{Colors.HEADER}{Colors.BOLD}"
            f"   GREEDY ALGORITHM ARCHITECT v5.0   "
            f"{Colors.ENDC}", 0.01)
        print("=" * 50)
        print(f"{Colors.CYAN}{Colors.BOLD}"
              f"   --- GREEDY ALGORITHMS IN GRAPHS ---"
              f"{Colors.ENDC}")
        print(f"{Colors.YELLOW}"
              f"  [18] Kruskal's MST      [19] Boruvka's MST\n"
              f"  [20] Prim's MST         [21] Dial's SSSP\n"
              f"  [22] Dijkstra's SSSP\n"
              f"\n  [0]  Exit System"
              f"{Colors.ENDC}")

        try:
            choice = input("\n> Choice: ").strip()
            if   choice == '18': kruskals()
            elif choice == '19': boruvkas()
            elif choice == '20': prims()
            elif choice == '21': dials()
            elif choice == '22': dijkstras()
            elif choice == '0':
                typewriter(f"{Colors.FAIL}Exiting...{Colors.ENDC}")
                break
            else:
                print(f"{Colors.FAIL}Invalid option '{choice}'. "
                      f"Choose 18-22 or 0.{Colors.ENDC}")
        except KeyboardInterrupt:
            print("\nShutting down...")
            break

if __name__ == "__main__":
    main_menu()
