import sys
import time
import math
import os

# --- 🎨 ZONE 1: COLOR THEORY & HIERARCHY ---
class Colors:
    HEADER = '\033[95m'  # Magenta: Professional Context
    LOGIC = '\033[93m'   # Yellow: Insight/Theory
    SUCCESS = '\033[92m' # Green: Optimal Solution
    FAIL = '\033[91m'    # Red: Error/Exclusion
    MENU = '\033[94m'    # Blue: Navigation
    CYAN = '\033[96m'    # Range/Processing
    BOLD = '\033[1m'
    ENDC = '\033[0m'

# --- ⌨️ ZONE 2: KINETIC TYPOGRAPHY ---
def typewriter(text, color=Colors.ENDC, speed=0.01):
    sys.stdout.write(color)
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print(Colors.ENDC)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# --- 📐 ZONE 3: LAYOUT ARCHITECTURE ---
def print_strategy_note(title, theory):
    print(f"\n{Colors.HEADER}{'='*50}")
    print(f" [STRATEGY NOTE]: {title}")
    print(f"{'='*50}{Colors.ENDC}")
    typewriter(theory, Colors.LOGIC)
    print(f"{Colors.HEADER}{'-'*50}{Colors.ENDC}\n")

def render_bars(arr, target=None, checking_idx=-1, checking_idx2=-1, low=-1, high=-1, found_idx=-1):
    if not arr: return
    max_val = max(arr)
    scale = 35 / max_val if max_val > 35 else 1

    # --- 💎 NEW: SEQUENCE VIEW (TOP DISPLAY) ---
    print(f" {Colors.CYAN}[ SEQUENCE VIEW ]{Colors.ENDC}")
    formatted_seq = []
    for i, x in enumerate(arr):
        if i == found_idx: formatted_seq.append(f"{Colors.SUCCESS}[{x}]{Colors.ENDC}")
        elif i == checking_idx or i == checking_idx2: formatted_seq.append(f"{Colors.FAIL}>{x}<{Colors.ENDC}")
        else: formatted_seq.append(str(x))
    print(f" {' → '.join(formatted_seq)}")
    print(f"{Colors.HEADER}{'-'*50}{Colors.ENDC}")

    print(f" {Colors.LOGIC}ANALYZING DATASET... (Target: {target}){Colors.ENDC}\n")
    for i, val in enumerate(arr):
        bar_len = int(val * scale)
        bar = "█" * bar_len
        
        icon = ">" 
        color = Colors.MENU
        
        if i == found_idx:
            color = Colors.SUCCESS
            icon = "[+]" 
        elif i == checking_idx or i == checking_idx2:
            color = Colors.FAIL
            icon = "[x]" 
        elif low <= i <= high and low != -1:
            color = Colors.CYAN
            icon = "%" 

        line = f" {icon} Index [{i:02d}] ({val:03d}): {color}{bar}{Colors.ENDC}"
        print(line)
    print(f"\n{Colors.HEADER}{'-'*50}{Colors.ENDC}")

# --- ⚙️ SEARCH MODULES ---

def linear_search_visual():
    print_strategy_note("LINEAR SEARCH", 
        "Scanning every element sequentially. No sorting required.\n"
        "Complexity: $O(n)$. Best for raw, unorganized streams.")
    raw = input(" > Enter dataset (space separated): ")
    arr = [int(x) for x in raw.split()]
    target = int(input(" > Target Value: "))
    
    for i in range(len(arr)):
        clear_screen()
        render_bars(arr, target, checking_idx=i)
        time.sleep(0.2)
        if arr[i] == target:
            clear_screen()
            render_bars(arr, target, found_idx=i)
            typewriter(f" [+] SUCCESS: Identified {target} at Index {i}", Colors.SUCCESS)
            return
    typewriter(" [x] REJECTION: Target not found in sequence.", Colors.FAIL)

def binary_search_visual():
    print_strategy_note("BINARY SEARCH", 
        "Repeatedly halving the search space. Requires sorted data.\n"
        "Complexity: $O(\log n)$. The gold standard for sorted arrays.")
    raw = input(f" > Enter dataset {Colors.CYAN}(will auto-sort){Colors.ENDC}: ")
    arr = sorted([int(x) for x in raw.split()])
    target = int(input(" > Target Value: "))
    
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        clear_screen()
        render_bars(arr, target, checking_idx=mid, low=low, high=high)
        time.sleep(0.6)
        if arr[mid] == target:
            clear_screen()
            render_bars(arr, target, found_idx=mid)
            typewriter(f" [+] SUCCESS: Captured {target} at Index {mid}", Colors.SUCCESS)
            return
        elif arr[mid] < target: low = mid + 1
        else: high = mid - 1
    typewriter(" [x] REJECTION: Data point missing from sorted set.", Colors.FAIL)

def interpolation_search_visual():
    print_strategy_note("INTERPOLATION SEARCH", 
        "Uses distribution estimation to 'guess' the position.\n"
        "Complexity: $O(\log(\log n))$ for uniform data. Best for sorted numeric ranges.")
    raw = input(f" > Enter dataset {Colors.CYAN}(will auto-sort){Colors.ENDC}: ")
    arr = sorted([int(x) for x in raw.split()])
    target = int(input(" > Target Value: "))
    
    low, high = 0, len(arr) - 1
    while low <= high and target >= arr[low] and target <= arr[high]:
        pos = low + int(((float(high - low) / (arr[high] - arr[low])) * (target - arr[low])))
        clear_screen()
        render_bars(arr, target, checking_idx=pos, low=low, high=high)
        time.sleep(0.8)
        
        if arr[pos] == target:
            clear_screen()
            render_bars(arr, target, found_idx=pos)
            typewriter(f" [+] SUCCESS: Estimation correct. Found at Index {pos}", Colors.SUCCESS)
            return
        if arr[pos] < target: low = pos + 1
        else: high = pos - 1
    typewriter(" [x] ERROR: Target out of bounds or missing.", Colors.FAIL)

def jump_search_visual():
    print_strategy_note("JUMP SEARCH", 
        "Leaping in fixed blocks. Good balance between Linear and Binary.\n"
        "Complexity: $O(\sqrt{n})$. Ideal when backwards steps are expensive.")
    raw = input(f" > Enter dataset {Colors.CYAN}(will auto-sort){Colors.ENDC}: ")
    arr = sorted([int(x) for x in raw.split()])
    target = int(input(" > Target Value: "))
    
    n = len(arr)
    step = int(math.sqrt(n))
    prev = 0
    while arr[min(step, n)-1] < target:
        clear_screen()
        render_bars(arr, target, checking_idx=min(step, n)-1, low=prev, high=min(step, n)-1)
        time.sleep(0.6)
        prev = step
        step += int(math.sqrt(n))
        if prev >= n: break
        
    for i in range(prev, min(step, n)):
        clear_screen()
        render_bars(arr, target, checking_idx=i, low=prev, high=min(step, n)-1)
        time.sleep(0.3)
        if arr[i] == target:
            clear_screen()
            render_bars(arr, target, found_idx=i)
            typewriter(f" [+] SUCCESS: Target located within block at Index {i}", Colors.SUCCESS)
            return
    typewriter(" [x] REJECTION: Block exhausted. No match.", Colors.FAIL)

def exponential_search_visual():
    print_strategy_note("EXPONENTIAL SEARCH", 
        "Exponentially increasing range then Binary searching.\n"
        "Complexity: $O(\log n)$. Best for unbounded datasets.")
    raw = input(f" > Enter dataset {Colors.CYAN}(will auto-sort){Colors.ENDC}: ")
    arr = sorted([int(x) for x in raw.split()])
    target = int(input(" > Target Value: "))
    
    if arr[0] == target:
        render_bars(arr, target, found_idx=0); return

    n, i = len(arr), 1
    while i < n and arr[i] <= target:
        clear_screen()
        render_bars(arr, target, checking_idx=i)
        time.sleep(0.6)
        i = i * 2

    low, high = i // 2, min(i, n - 1)
    while low <= high:
        mid = (low + high) // 2
        clear_screen()
        render_bars(arr, target, checking_idx=mid, low=low, high=high)
        time.sleep(0.6)
        if arr[mid] == target:
            clear_screen()
            render_bars(arr, target, found_idx=mid)
            typewriter(f" [+] SUCCESS: Binary sub-search matched Index {mid}", Colors.SUCCESS)
            return
        elif arr[mid] < target: low = mid + 1
        else: high = mid - 1
    typewriter(" [x] REJECTION: Search range exhausted.", Colors.FAIL)

def ternary_search_visual():
    print_strategy_note("TERNARY SEARCH", 
        "Splitting range into three equal segments via two midpoints.\n"
        "Complexity: $O(\log_3 n)$.")
    raw = input(f" > Enter dataset {Colors.CYAN}(will auto-sort){Colors.ENDC}: ")
    arr = sorted([int(x) for x in raw.split()])
    target = int(input(" > Target Value: "))
    
    low, high = 0, len(arr) - 1
    while low <= high:
        m1 = low + (high - low) // 3
        m2 = high - (high - low) // 3
        clear_screen()
        render_bars(arr, target, checking_idx=m1, checking_idx2=m2, low=low, high=high)
        time.sleep(0.8)
        if arr[m1] == target:
            clear_screen()
            render_bars(arr, target, found_idx=m1); return
        if arr[m2] == target:
            clear_screen()
            render_bars(arr, target, found_idx=m2); return
        if target < arr[m1]: high = m1 - 1
        elif target > arr[m2]: low = m2 + 1
        else: low, high = m1 + 1, m2 - 1
    typewriter(" [x] REJECTION: No match found.", Colors.FAIL)

# --- 🏁 MAIN INTERFACE ---
def main():
    while True:
        clear_screen()
        print(f"{Colors.BOLD}{Colors.HEADER}=============================================")
        print("      DATA-BAR SEARCH ARCHITECT v7.5       ")
        print(f"============================================={Colors.ENDC}")
        print(f"{Colors.MENU} [1] Linear Search      [2] Binary Search")
        print(f" [3] Interpolation      [4] Jump Search")
        print(f" [5] Exponential        [6] Ternary Search")
        print(f" [0] Exit Program{Colors.ENDC}")
        print(f"{Colors.HEADER}============================================={Colors.ENDC}")
        print(f"{Colors.LOGIC} [*] SYSTEM NOTE: Raw inputs are automatically ")
        print(f"     sorted for efficient searching.{Colors.ENDC}")
        
        choice = input("\n [SYSTEM SELECT]: ")
        
        if choice == '1': linear_search_visual()
        elif choice == '2': binary_search_visual()
        elif choice == '3': interpolation_search_visual()
        elif choice == '4': jump_search_visual()
        elif choice == '5': exponential_search_visual()
        elif choice == '6': ternary_search_visual()
        elif choice == '0': 
            typewriter(" [x] DEACTIVATING MAINFRAME...", Colors.FAIL)
            break
        else: continue
        input(f"\n{Colors.LOGIC}Process Complete. Press Enter to return...{Colors.ENDC}")

if __name__ == "__main__":
    main()
